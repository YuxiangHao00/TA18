<?php
/*
Plugin Name: Traffic Accident Heatmap
Description: Displays a heatmap of traffic accidents in Melbourne
Version: 1.5
Author: YuxiangHao
*/

// Include necessary files
include_once(plugin_dir_path(__FILE__) . 'tacm_enqueue_scripts.php');
include_once(plugin_dir_path(__FILE__) . 'tacm_shortcode.php');
?>
